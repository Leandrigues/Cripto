EP1 de MAC0336
Nome: Leandro Rodrigues da Silva
nUSP: 10723944

Arquivos inclusos:
    ep.py
    Os arquivos documentoX e arqX são gerados pelo programa em tempo de execução

Para rodar:
    sage ep.py (ou python3 ep.py)

Versão utilizada:
    Foi utilizada a versão 9.0 do SageMath e o python3.

Respostas dissertativas:
    Exercício 17: É desejável que a distância de Hamming seja maior possível nesse caso, pois queremos
    que a criptografia utilizada tenha a propriedade de "confusão", de forma a gerar entropia na saída
    do texto criptogrado, ou seja, apenas a mudança de 1 bit na entrada do textado às claras deve gerar
    uma mudança em vários bits na saída de forma a evitar ataques.

    Exercício 20: Queremos que a distância de Hamming seja grande, pois assim, com dois textos criptografados
    gerados a partir de um mesmo texto (porém com chaves diferentes), serão muito diferentes, diminuindo a chance
    de que sejam obtidas possíveis informações sobre o texto original.